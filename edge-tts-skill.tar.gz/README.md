# Edge TTS Service

一个基于微软 Edge TTS 的自托管文本转语音 API 服务。

![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## 特性

- 💰 **完全免费** - 无需 API Key 或 Azure 账户
- 🎙️ **高音质** - 神经网络语音合成
- 🌏 **多语言** - 支持 40+ 语言和音色
- ⚡ **简单易用** - RESTful API，自动文档
- 🐳 **容器化** - Docker 一键部署

## 快速开始

### 使用 Docker（推荐）

```bash
git clone https://github.com/your-username/edge-tts-skill.git
cd edge-tts-skill
docker-compose up -d
```

服务将在 `http://localhost:8000` 启动。

### 本地运行

```bash
# 安装依赖
pip install -r requirements.txt

# 启动服务
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## API 使用

### 文本转语音

```bash
curl -X POST http://localhost:8000/tts \
  -H "Content-Type: application/json" \
  -d '{"text": "你好，世界"}' \
  --output speech.mp3
```

### 获取音色列表

```bash
curl http://localhost:8000/voices
```

### 查看文档

访问 `http://localhost:8000/docs` 查看交互式 API 文档。

## 配置

通过环境变量配置（可选）：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `SERVICE_PORT` | `8000` | 服务端口 |
| `LOG_LEVEL` | `INFO` | 日志级别 |

## 集成示例

### Python

```python
import requests

response = requests.post(
    "http://localhost:8000/tts",
    json={"text": "你好，世界", "voice": "zh-CN-XiaoxiaoNeural"}
)
with open("speech.mp3", "wb") as f:
    f.write(response.content)
```

### JavaScript

```javascript
const response = await fetch('http://localhost:8000/tts', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({text: '你好，世界'})
});
const audio = await response.blob();
```

## 项目结构

```
edge-tts-skill/
├── app/                    # FastAPI 应用
│   ├── main.py
│   ├── routes/
│   ├── services/
│   └── models/
├── scripts/                # 部署脚本
├── docker/                 # Docker 配置
├── examples/               # 使用示例
└── docs/                   # 文档
```

## License

MIT
