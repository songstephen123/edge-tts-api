---
name: edge-tts-service
description: "Use this skill whenever the user wants to deploy a self-hosted TTS API service using Microsoft Edge TTS (completely free, no API key required). Triggers include: 'deploy tts service', 'tts api server', 'self-hosted tts', 'edge tts service', 'microsoft tts service', or requests to set up a text-to-speech API that can be called from Feishu, DingTalk, or other applications."
---

# edge-tts-service

一个基于微软 Edge TTS 的自托管 API 服务，**完全免费，无需 API Key**，可被飞书、钉钉等应用调用。

## Highlights

- 💰 **完全免费** - 使用 Edge TTS，无需 Azure 账户或 API Key
- 🎙️ **神经网络音质** - 与 Azure TTS 相同的高质量语音
- 🌏 **多语言支持** - 中文、英文、日文等 40+ 语言
- ⚡ **快速响应** - RESTful API 设计
- 🔌 **通用接口** - 可接入任何应用（飞书、钉钉、微信...）
- 🐳 **一键部署** - Docker 支持

## Triggers

- 部署 tts 服务 / tts api / 语音服务
- 飞书机器人 tts / 钉钉语音播报
- edge tts / 免费 tts / 无需 api key
- 自托管 tts / self-hosted tts

## Quick Start

### 1. 安装

```bash
git clone https://github.com/your-username/edge-tts-skill.git
cd edge-tts-skill
bash scripts/install.sh
```

### 2. 启动

```bash
# Docker 方式（推荐）
docker-compose up -d

# 或直接运行
bash scripts/start.sh
```

### 3. 调用

```bash
curl -X POST http://localhost:8000/tts \
  -H "Content-Type: application/json" \
  -d '{"text": "你好，世界"}'
```

## API Endpoints

### POST /tts

将文本转换为语音。

**请求：**
```json
{
  "text": "你好，这是一条测试消息",
  "voice": "zh-CN-XiaoxiaoNeural",
  "rate": "+0%",
  "pitch": "+0Hz",
  "volume": "+0%"
}
```

**响应：** 返回音频文件 (audio/mpeg)

### GET /voices

获取所有可用音色列表。

**响应：**
```json
{
  "voices": [
    {"name": "zh-CN-XiaoxiaoNeural", "locale": "zh-CN", "gender": "Female"},
    {"name": "zh-CN-YunyangNeural", "locale": "zh-CN", "gender": "Male"},
    ...
  ]
}
```

### GET /health

健康检查。

**响应：**
```json
{
  "status": "healthy",
  "service": "edge-tts-service",
  "version": "1.0.0"
}
```

## Requirements

- Python 3.10+
- Docker（可选，推荐）

## Available Voices

### 中文音色

| 音色 ID | 性别 | 特点 |
|---------|------|------|
| `zh-CN-XiaoxiaoNeural` | 女 | 温柔（默认） |
| `zh-CN-XiaoyiNeural` | 女 | 亲和 |
| `zh-CN-XiaohanNeural` | 女 | 清脆 |
| `zh-CN-XiaomengNeural` | 女 | 童声 |
| `zh-CN-YunyangNeural` | 男 | 成熟 |
| `zh-CN-YunjianNeural` | 男 | 沉稳 |

### 英文音色

| 音色 ID | 性别 | 特点 |
|---------|------|------|
| `en-US-AriaNeural` | 女 | 标准 |
| `en-US-GuyNeural` | 男 | 成熟 |
| `en-GB-SoniaNeural` | 女 | 英式英语 |

更多音色请调用 `/voices` 接口查看。

## Integration Examples

### 飞书机器人示例

```python
# examples/feishu_bot.py
import requests

def send_feishu_voice(text, webhook_url):
    response = requests.post(
        "http://localhost:8000/tts",
        json={"text": text}
    )
    # 发送音频到飞书...
```

完整示例见 `examples/` 目录。

## Parameters

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `text` | string | 必填 | 要转换的文本 |
| `voice` | string | `zh-CN-XiaoxiaoNeural` | 音色 ID |
| `rate` | string | `+0%` | 语速 (-50% ~ +100%) |
| `pitch` | string | `+0Hz` | 音调 (-50Hz ~ +50Hz) |
| `volume` | string | `+0%` | 音量 (-50% ~ +100%) |

## Limitations

- Edge TTS 通过逆向工程实现，未来可能有变化
- 不支持 SSML 高级功能（如停顿、重音）
- 建议用于个人和非商业项目

## Troubleshooting

### 端口被占用
修改 `.env` 中的 `SERVICE_PORT` 或 `docker-compose.yml` 中的端口映射。

### 音色列表为空
检查网络连接，确保可以访问 Edge TTS 服务。

## License

MIT License
